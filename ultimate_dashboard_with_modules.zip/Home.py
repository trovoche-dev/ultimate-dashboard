
import streamlit as st

st.set_page_config(page_title="Ultimate Trading Dashboard", layout="wide")

st.title("📊 Ultimate Trading Dashboard")
st.write("Choose a module from the sidebar to get started.")
