
#!/usr/bin/env python3
import os, subprocess, webbrowser

repo_url = "https://github.com/trovoche-dev/ultimate_dashboard.git"
branch_name = "main"

print("📦 Initializing repo...")
subprocess.run(["git", "init"])
subprocess.run(["git", "branch", "-M", branch_name])

print("🔗 Adding remote...")
subprocess.run(["git", "remote", "add", "origin", repo_url], stderr=subprocess.DEVNULL)

print("💾 Committing...")
subprocess.run(["git", "add", "."])
subprocess.run(["git", "commit", "-m", "Deploy full ultimate dashboard with modules"])

print("📤 Pushing...")
subprocess.run(["git", "push", "-u", "origin", branch_name, "--force"])

print("🌐 Opening Streamlit Cloud...")
webbrowser.open("https://share.streamlit.io/new")

print("✅ Deployment finished!")
