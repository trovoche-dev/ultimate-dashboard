
import streamlit as st
import yfinance as yf
import pandas as pd

st.title("🚀 Top Movers Scanner")

tickers = ["AAPL","NVDA","TSLA","MSFT","AMZN","META","NFLX"]

data = {}

for t in tickers:
    df = yf.download(t, period="5d")
    change = (df['Close'][-1] - df['Close'][0]) / df['Close'][0] * 100
    data[t] = change

st.write(pd.DataFrame({"Symbol": data.keys(), "Change %": data.values()}))
