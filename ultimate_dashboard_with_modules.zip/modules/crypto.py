
import streamlit as st
import ccxt
import pandas as pd

st.title("💰 Crypto Module")

exchange = ccxt.binance()
symbol = st.text_input("Enter crypto pair", "BTC/USDT")

if symbol:
    ohlcv = exchange.fetch_ohlcv(symbol, timeframe="1h", limit=100)
    df = pd.DataFrame(ohlcv, columns=["Time","Open","High","Low","Close","Volume"])
    st.line_chart(df["Close"])
