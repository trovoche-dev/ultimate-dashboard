
import streamlit as st
import pandas as pd
import yfinance as yf

st.title("📈 Stocks Module")

symbol = st.text_input("Enter stock symbol", "AAPL")

if symbol:
    data = yf.download(symbol, period="1mo", interval="1d")
    st.line_chart(data['Close'])
